Liam: Most of the C functions.

Trevor: Most of the assembly functions.

Together: assembly str_compare, C main function functionality, general debugging.

Altogether, amazing teamwork.

MS2:
Liam:
Trevor:
