Liam: Most of the C functions, some of the assembly funcitons.

Trevor: Most of the assembly function, some of the C functions, most of C main functionality.