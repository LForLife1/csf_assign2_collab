Liam: Most of the C functions.

Trevor: Most of the assembly functions.

Together: assembly str_compare, C main function functionality, general debugging.

Altogether, amazing teamwork.

MS2:

We both worked on all of the assembly functions, both in writing and debugging them.
Basically 50/50 because we both had to work significantly on every function. 
